package com.takemytickets.online.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.takemytickets.online.model.Rating;
import com.takemytickets.online.model.User;
import com.takemytickets.online.repository.RatingRepository;
import com.takemytickets.online.repository.UserRepository;

@RestController
@RequestMapping("/rating")
public class Ratingcontroller {

    @Autowired
    private RatingRepository ratingRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/add")
    public String addRating(
            @RequestParam int userId,
            @RequestParam int entityId,
            @RequestParam String entityType,
            @RequestParam int ratingValue) {

        // Fetch user
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Create rating
        Rating rating = new Rating();
        rating.setUserid(userId);          // set User entity
        rating.setEntityId(entityId);
        rating.setEntityType(entityType);
        rating.setRatingValue(ratingValue);

        // Save
        ratingRepository.save(rating);

        return "Rating added successfully!";
    }
    @GetMapping("/get")
    public String getRating(
            @RequestParam int userId,
            @RequestParam int entityId,
            @RequestParam String entityType) {

        // Fetch user
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Create rating
        List<Rating> rating = ratingRepository.findByEntityIdAndUserIdAndEntityType(entityId,userId,entityType);

        // Save

        return "Rating :" + rating.get(0).getRatingValue();
    }
}
