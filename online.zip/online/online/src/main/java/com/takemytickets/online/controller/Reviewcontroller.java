package com.takemytickets.online.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.takemytickets.online.model.Review;
import com.takemytickets.online.model.User;
import com.takemytickets.online.model.Event;
import com.takemytickets.online.repository.EventRepository;
import com.takemytickets.online.repository.ReviewRepository;
import com.takemytickets.online.repository.UserRepository;

@RestController
@RequestMapping("/review")
public class Reviewcontroller {
	
	@Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/add")
    public String addReview(
            @RequestParam int userId,
            @RequestParam int entityId,
            @RequestParam String entityType,
            @RequestParam String reviewValue) {

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Create rating
        Review rating = new Review();
        rating.setUserid(userId);          
        rating.setEntityId(entityId);
        rating.setEntityType(entityType);
        rating.setReviewValue(reviewValue);

        // Save
        reviewRepository.save(rating);

        return "Review added successfully!";
    }
    @GetMapping("/get")
    public String getReview(
            @RequestParam int userId,
            @RequestParam int entityId,
            @RequestParam String entityType) {

        // Fetch user
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Create rating
        List<Review> rating = reviewRepository.findByEntityIdAndUserIdAndEntityType(entityId,userId,entityType);

        // Save

        return "Review :" + rating.get(0).getReviewValue();
    }
    @GetMapping("/test")
    public String test() {

        return "hello";
    }
}

