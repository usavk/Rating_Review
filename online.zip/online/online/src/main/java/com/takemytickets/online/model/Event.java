package com.takemytickets.online.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Table(name = "event")
@Data
public class Event {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "event_id")
    int eventId;

    @Column(name = "eventname")
    String eventname;
    
    @Column(name = "fee")
    int fee;
}
