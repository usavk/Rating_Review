package com.takemytickets.online.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "event_user")
@Data
public class EventUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int eventUserId;

    @Column(name = "event_id")
    int eventId;

    @Column(name = "user_id")
    int userId;
}
