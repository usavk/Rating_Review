package com.takemytickets.online.model;

import jakarta.persistence.*;
import lombok.Data;

import java.sql.Timestamp;

@Entity
@Table(name = "rating")
@Data
public class Rating {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name ="rating_id")
    private int ratingId;

    @Column(name = "user_id")
    private int userId;

    @Column(name ="entity_id")
    private int entityId;

    @Column(name ="entity_type")
    private String entityType;

    @Column(name ="rating_value")
    private int ratingValue;

    
    @Column(name = "created_at", nullable = false, updatable = false)
    private Timestamp createdAt = new Timestamp(System.currentTimeMillis());


	public int getRatingId() {
		return ratingId;
	}


	public void setRatingId(int ratingId) {
		this.ratingId = ratingId;
	}


	public int getUserid() {
		return userId;
	}


	public void setUserid(int userid) {
		this.userId = userid;
	}


	public int getEntityId() {
		return entityId;
	}


	public void setEntityId(int entityId) {
		this.entityId = entityId;
	}


	public String getEntityType() {
		return entityType;
	}


	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}


	public int getRatingValue() {
		return ratingValue;
	}


	public void setRatingValue(int ratingValue) {
		this.ratingValue = ratingValue;
	}


	public Timestamp getCreatedAt() {
		return createdAt;
	}


	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}
    
    
    
}
