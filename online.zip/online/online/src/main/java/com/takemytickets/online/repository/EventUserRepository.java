package com.takemytickets.online.repository;

import com.takemytickets.online.model.EventUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EventUserRepository extends JpaRepository<EventUser, Integer> {
    // Get all events booked by a userId
    List<EventUser> findByUserId(int userId);

    // Get all users booked for an eventId
    List<EventUser> findByEventId(int eventId);
}
