package com.takemytickets.online.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.takemytickets.online.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

    User findByUserId(int userId);
}
